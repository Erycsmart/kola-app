import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getDatabase, ref, onValue, get, update, push } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/* FIREBASE CONFIG */
const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

let currentRole = "";

/* AUTH CHECK */
onAuthStateChanged(auth, async (user) => {
  if (!user) return location.href = "admin-login.html";

  const snap = await get(ref(db, "admins/" + user.uid));
  if (!snap.exists()) {
    await signOut(auth);
    return location.href = "admin-login.html";
  }

  currentRole = snap.val().role;
  loadStats();
  loadWithdraws();
  loadUsers();
  loadAdmins();
  loadLogs();
});

/* THEME */
const themeBtn = document.getElementById("themeToggle");
if(localStorage.getItem("theme")==="light"){
  document.body.classList.add("light");
}
themeBtn.onclick = () => {
  document.body.classList.toggle("light");
  localStorage.setItem("theme",
    document.body.classList.contains("light") ? "light" : "dark"
  );
};

/* LOGOUT */
document.getElementById("logoutBtn").onclick = () => {
  signOut(auth).then(()=> location.href="admin-login.html");
};

/* STATS */
function loadStats(){
  onValue(ref(db,"users"), snap=>{
    let count=0, wallet=0;
    snap.forEach(u=>{
      count++;
      wallet+=Number(u.val().wallet||0);
    });
    document.getElementById("totalUsers").innerText=count;
    document.getElementById("totalWallet").innerText=wallet;
  });

  onValue(ref(db,"withdrawRequests"), snap=>{
    let pending=0, paid=0;
    snap.forEach(w=>{
      if(w.val().status==="pending") pending++;
      if(w.val().status==="approved") paid+=Number(w.val().amount);
    });
    document.getElementById("pendingWithdraw").innerText=pending;
    document.getElementById("totalPaid").innerText=paid;
  });

  loadChart();
}

/* CHART */
function loadChart(){
  onValue(ref(db,"withdrawRequests"), snap=>{
    let approved=0,rejected=0;
    snap.forEach(w=>{
      if(w.val().status==="approved") approved++;
      if(w.val().status==="rejected") rejected++;
    });

    new Chart(document.getElementById("revenueChart"),{
      type:"bar",
      data:{
        labels:["Approved","Rejected"],
        datasets:[{
          data:[approved,rejected]
        }]
      }
    });
  });
}

/* WITHDRAW */
function loadWithdraws(){
  onValue(ref(db,"withdrawRequests"), snap=>{
    const list=document.getElementById("withdrawList");
    list.innerHTML="";
    snap.forEach(w=>{
      const d=w.val();
      const div=document.createElement("div");
      div.innerHTML=`
        ${d.userEmail} - ${d.amount} (${d.status})
        ${d.status==="pending"?
          `<button onclick="approve('${w.key}','${d.uid}',${d.amount})">Approve</button>
           <button onclick="reject('${w.key}')">Reject</button>`:""}
      `;
      list.appendChild(div);
    });
  });
}

window.approve = async(id,uid,amount)=>{
  await update(ref(db,"withdrawRequests/"+id),{status:"approved"});
  const userRef=ref(db,"users/"+uid);
  const snap=await get(userRef);
  const newWallet=Number(snap.val().wallet||0)-amount;
  await update(userRef,{wallet:newWallet});
  log("Approved withdraw "+amount);
};

window.reject = async(id)=>{
  await update(ref(db,"withdrawRequests/"+id),{status:"rejected"});
  log("Rejected withdraw");
};

/* USERS */
function loadUsers(){
  onValue(ref(db,"users"), snap=>{
    const list=document.getElementById("userList");
    list.innerHTML="";
    snap.forEach(u=>{
      const d=u.val();
      const div=document.createElement("div");
      div.innerHTML=`
        ${d.email||u.key} - Wallet: ${d.wallet||0}
        ${currentRole==="superadmin"?
        `<button onclick="ban('${u.key}')">Ban</button>`:""}
      `;
      list.appendChild(div);
    });
  });
}

window.ban=async(uid)=>{
  await update(ref(db,"users/"+uid),{banned:true});
  log("Banned user "+uid);
};

/* ADMIN MANAGEMENT */
function loadAdmins(){
  if(currentRole!=="superadmin"){
    document.getElementById("adminSection").style.display="none";
    return;
  }

  onValue(ref(db,"admins"), snap=>{
    const list=document.getElementById("adminList");
    list.innerHTML="";
    snap.forEach(a=>{
      list.innerHTML+=`<div>${a.val().email} - ${a.val().role}</div>`;
    });
  });
}

document.getElementById("addAdminBtn").onclick=async()=>{
  if(currentRole!=="superadmin") return;
  const email=document.getElementById("newAdminEmail").value;
  const role=document.getElementById("adminRole").value;

  const usersSnap=await get(ref(db,"users"));
  usersSnap.forEach(u=>{
    if(u.val().email===email){
      update(ref(db,"admins/"+u.key),{email,role});
      log("Added admin "+email);
    }
  });
};

/* LOGS */
function log(text){
  push(ref(db,"adminLogs"),{
    text,
    time:Date.now()
  });
}

function loadLogs(){
  onValue(ref(db,"adminLogs"), snap=>{
    const list=document.getElementById("logList");
    list.innerHTML="";
    snap.forEach(l=>{
      list.innerHTML+=`<div>${l.val().text}</div>`;
    });
  });
}