import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged } 
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getDatabase, ref, onValue, runTransaction } 
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

const usernameEl = document.getElementById("username");
const walletEl = document.getElementById("wallet");
const levelEl = document.getElementById("level");
const rewardRangeEl = document.getElementById("rewardRange");
const progressText = document.getElementById("progressText");
const progressFill = document.getElementById("progressFill");
const dailyText = document.getElementById("dailyText");
const dailyFill = document.getElementById("dailyFill");
const watchBtn = document.getElementById("watchBtn");
const timerEl = document.getElementById("timer");
const msgEl = document.getElementById("msg");

let currentUser;
let isWatching = false;

onAuthStateChanged(auth, (user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }

  currentUser = user;
  usernameEl.innerText = user.email.split("@")[0];

  const userRef = ref(db, "users/" + user.uid);

  onValue(userRef, (snap) => {
    const data = snap.val();
    if (!data) return;

    walletEl.innerText = "UGX " + (data.wallet || 0).toLocaleString();
    levelEl.innerText = data.level || 1;

    updateLevelUI(data);
    updateDailyUI(data);
  });
});

watchBtn.addEventListener("click", () => {
  if (isWatching) return;
  startTimer();
});

function startTimer() {
  isWatching = true;
  watchBtn.disabled = true;

  let seconds = 30;
  timerEl.innerText = `Watching... ${seconds}s`;

  const interval = setInterval(() => {
    seconds--;
    timerEl.innerText = `Watching... ${seconds}s`;

    if (seconds <= 0) {
      clearInterval(interval);
      rewardUser();
    }
  }, 1000);
}

function rewardUser() {

  const userRef = ref(db, "users/" + currentUser.uid);

  runTransaction(userRef, (data) => {

    if (!data) return data;

    const today = new Date().toISOString().split("T")[0];

    if (data.lastResetDate !== today) {
      data.dailyAdsWatched = 0;
      data.lastResetDate = today;
    }

    if ((data.dailyAdsWatched || 0) >= 10) {
      msgEl.innerText = "Daily limit reached!";
      return data;
    }

    let reward = calculateReward(data);

    data.wallet = (data.wallet || 0) + reward;
    data.dailyAdsWatched = (data.dailyAdsWatched || 0) + 1;
    data.totalVideosWatched = (data.totalVideosWatched || 0) + 1;
    data.levelVideosWatched = (data.levelVideosWatched || 0) + 1;

    checkLevelUpgrade(data);

    msgEl.innerText = `You earned UGX ${reward}`;
    return data;

  }).then(() => {
    timerEl.innerText = "";
    watchBtn.disabled = false;
    isWatching = false;
  });
}

function calculateReward(data) {
  switch (data.level) {
    case 1: return random(200, 500);
    case 2: return random(600, 1500);
    case 3: return random(2000, 3000);
    case 4: return random(3500, 4500);
    default: return random(2000, 3000);
  }
}

function checkLevelUpgrade(data) {

  const requirements = {
    1: 30,
    2: 45,
    3: 50,
    4: 65
  };

  const needed = requirements[data.level];

  if (needed && data.levelVideosWatched >= needed) {
    data.level++;
    data.levelVideosWatched = 0;
  }
}

function updateLevelUI(data) {

  const requirements = {
    1: 30,
    2: 45,
    3: 50,
    4: 65
  };

  const ranges = {
    1: "UGX 200 - 500 per Ad",
    2: "UGX 600 - 1500 per Ad",
    3: "UGX 2000 - 3000 per Ad",
    4: "UGX 3500 - 4500 per Ad",
    5: "Premium Level"
  };

  rewardRangeEl.innerText = ranges[data.level] || "";

  const needed = requirements[data.level] || 1;
  const watched = data.levelVideosWatched || 0;

  progressText.innerText = `${watched} / ${needed}`;
  progressFill.style.width = (watched / needed) * 100 + "%";
}

function updateDailyUI(data) {

  const watched = data.dailyAdsWatched || 0;

  dailyText.innerText = `${watched} / 10`;
  dailyFill.style.width = (watched / 10) * 100 + "%";
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}