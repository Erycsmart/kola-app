import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword }
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getDatabase, ref, get }
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/* FIREBASE */
const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

/* SIGN UP */
document.getElementById("signupBtn").onclick = async () => {

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const referral = document.getElementById("referral").value.trim();

  if (!email || !password) {
    alert("Fill all required fields");
    return;
  }

  try {

    // 🔥 IF REFERRAL ENTERED → VALIDATE FIRST
    if (referral) {
      const snap = await get(ref(db, "referralCodes/" + referral));

      if (!snap.exists()) {
        alert("Invalid referral code.");
        return; // stop signup
      }
    }

    // Create account
    await createUserWithEmailAndPassword(auth, email, password);

    // Redirect with referral param if valid
    if (referral) {
      window.location.href = "dashboard.html?ref=" + referral;
    } else {
      window.location.href = "dashboard.html";
    }

  } catch (error) {
    alert(error.message);
  }
};