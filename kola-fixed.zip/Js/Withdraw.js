import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged } 
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getDatabase, ref, onValue, push, runTransaction, get } 
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

const walletEl = document.getElementById("wallet");
const levelEl = document.getElementById("level");
const badge = document.getElementById("statusBadge");
const amountInput = document.getElementById("amount");
const networkInput = document.getElementById("network");
const phoneInput = document.getElementById("phone");
const withdrawBtn = document.getElementById("withdrawBtn");
const msg = document.getElementById("msg");

let currentUser;
let currentData;

onAuthStateChanged(auth, (user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }

  currentUser = user;
  const userRef = ref(db, "users/" + user.uid);

  onValue(userRef, (snap) => {
    const data = snap.val();
    if (!data) return;

    currentData = data;

    walletEl.innerText = "UGX " + (data.wallet || 0).toLocaleString();
    levelEl.innerText = data.level || 1;

    checkEligibility(data);
  });
});

function checkEligibility(data) {

  if (data.pendingWithdrawal) {
    badge.className = "badge pending";
    badge.innerText = "🟠 Pending Withdrawal";
    withdrawBtn.disabled = true;
    return;
  }

  if (data.level < 5) {
    badge.className = "badge locked";
    badge.innerText = "🔴 Locked – Reach Level 5";
    withdrawBtn.disabled = true;
    return;
  }

  badge.className = "badge eligible";
  badge.innerText = "🟢 Eligible for Withdrawal";
  withdrawBtn.disabled = false;
}

withdrawBtn.addEventListener("click", async () => {

  const amount = parseInt(amountInput.value);
  const network = networkInput.value;
  const phone = phoneInput.value.trim();

  msg.innerText = "";

  if (!amount || amount < 45000 || amount > 100000) {
    msg.innerText = "Amount must be between 45,000 and 100,000.";
    return;
  }

  if (amount > currentData.wallet) {
    msg.innerText = "Insufficient wallet balance.";
    return;
  }

  if (!network) {
    msg.innerText = "Select network.";
    return;
  }

  if (!phone) {
    msg.innerText = "Enter phone number.";
    return;
  }

  const userRef = ref(db, "users/" + currentUser.uid);

  await runTransaction(userRef, (data) => {
    if (!data) return data;

    if (data.wallet < amount) return data;

    data.wallet -= amount;
    data.pendingWithdrawal = true;

    return data;
  });

  await push(ref(db, "withdrawals"), {
    uid: currentUser.uid,
    amount,
    phone,
    network,
    status: "pending",
    createdAt: Date.now()
  });

  msg.innerText = 
    "Withdrawal submitted successfully. Processing takes 2–3 business days.";

});