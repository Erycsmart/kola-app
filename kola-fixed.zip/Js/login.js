// 🔥 Import Firebase v9
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } 
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
/***********************
 🔥 FIREBASE CONFIG
************************/
const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

// 🔥 Initialize
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// 👁 Toggle Password
window.togglePassword = function () {
  const input = document.getElementById("password");
  input.type = input.type === "password" ? "text" : "password";
};

// 🔐 Login Function
window.login = async function () {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const msg = document.getElementById("msg");

  if (!email || !password) {
    msg.innerText = "Please enter email and password";
    return;
  }

  msg.innerText = "Logging in...";

  try {
    await signInWithEmailAndPassword(auth, email, password);
    window.location.href = "dashboard.html";
  } catch (error) {
    msg.innerText = error.message;
  }
};