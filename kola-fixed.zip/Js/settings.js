import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { 
  getAuth, 
  onAuthStateChanged, 
  EmailAuthProvider,
  reauthenticateWithCredential,
  updatePassword,
  signOut
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

import { 
  getDatabase, 
  ref, 
  onValue, 
  update 
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/***********************
 FIREBASE CONFIG
************************/
const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

/***********************
 AUTH STATE
************************/
onAuthStateChanged(auth, (user) => {

  if (!user) {
    window.location.href = "index.html";
    return;
  }

  const uid = user.uid;
  const userRef = ref(db, "users/" + uid);

  const displayUsername = document.getElementById("displayUsername");
  const usernameInput = document.getElementById("usernameInput");
  const editBtn = document.getElementById("editUsernameBtn");
  const saveBtn = document.getElementById("saveUsernameBtn");

  const walletEl = document.getElementById("wallet");
  const levelEl = document.getElementById("level");
  const videosEl = document.getElementById("videos");
  const earningsEl = document.getElementById("earnings");

  const networkSelect = document.getElementById("network");
  const phoneInput = document.getElementById("phone");
  const saveWithdrawBtn = document.getElementById("saveWithdrawBtn");

  const backBtn = document.getElementById("backBtn");
  const logoutBtn = document.getElementById("logoutBtn");

  const currentPasswordInput = document.getElementById("currentPassword");
  const newPasswordInput = document.getElementById("newPassword");
  const confirmPasswordInput = document.getElementById("confirmPassword");
  const savePasswordBtn = document.getElementById("savePasswordBtn");

  const displayEmail = document.getElementById("displayEmail");
  const levelBadge = document.getElementById("levelBadge");

  displayEmail.innerText = user.email;

  /***********************
   REALTIME DATA
  ************************/
  onValue(userRef, (snapshot) => {

    const data = snapshot.val();
    if (!data) return;

    displayUsername.innerText = data.username || user.email.split("@")[0];
    usernameInput.value = data.username || user.email.split("@")[0];

    walletEl.innerText = "UGX " + (data.wallet || 0).toLocaleString();
    levelEl.innerText = data.level || 1;
    videosEl.innerText = data.totalVideosWatched || 0;
    earningsEl.innerText = "UGX " + (data.lifetimeEarnings || 0).toLocaleString();

    levelBadge.innerText = "Level " + (data.level || 1);

    if (data.withdrawSettings) {
      networkSelect.value = data.withdrawSettings.network || "MTN";
      phoneInput.value = data.withdrawSettings.phone || "";
    }
  });

  /***********************
   USERNAME EDIT
  ************************/
  editBtn.onclick = () => {
    displayUsername.classList.add("hidden");
    usernameInput.classList.remove("hidden");
    saveBtn.classList.remove("hidden");
    editBtn.classList.add("hidden");
  };

  saveBtn.onclick = async () => {

    const newUsername = usernameInput.value.trim();

    if (newUsername.length < 3) {
      alert("Username must be at least 3 characters.");
      return;
    }

    await update(userRef, { username: newUsername });

    displayUsername.classList.remove("hidden");
    usernameInput.classList.add("hidden");
    saveBtn.classList.add("hidden");
    editBtn.classList.remove("hidden");

    alert("Username updated successfully");
  };

  /***********************
   SAVE WITHDRAW SETTINGS
  ************************/
  saveWithdrawBtn.onclick = async () => {

    const network = networkSelect.value;
    const phone = phoneInput.value.trim();

    if (phone.length < 9) {
      alert("Enter valid phone number.");
      return;
    }

    await update(userRef, {
      withdrawSettings: { network, phone }
    });

    alert("Withdrawal settings saved");
  };

  /***********************
   PASSWORD CHANGE
  ************************/
  savePasswordBtn.onclick = async () => {

    const currentPassword = currentPasswordInput.value.trim();
    const newPassword = newPasswordInput.value.trim();
    const confirmPassword = confirmPasswordInput.value.trim();

    if (!currentPassword || !newPassword || !confirmPassword) {
      alert("Fill all password fields.");
      return;
    }

    if (newPassword.length < 6) {
      alert("New password must be at least 6 characters.");
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    try {
      const credential = EmailAuthProvider.credential(
        user.email,
        currentPassword
      );

      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPassword);

      alert("Password updated successfully");

      currentPasswordInput.value = "";
      newPasswordInput.value = "";
      confirmPasswordInput.value = "";

    } catch (error) {
      alert(error.message);
      console.error(error);
    }
  };

  /***********************
   BACK BUTTON
  ************************/
  backBtn.onclick = () => {
    window.location.href = "dashboard.html";
  };

  /***********************
   LOGOUT
  ************************/
  logoutBtn.onclick = async () => {
    await signOut(auth);
    window.location.href = "index.html";
  };

});