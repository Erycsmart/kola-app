import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut }
from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  onValue,
  set,
  update,
  get,
  runTransaction,
  query,
  orderByChild,
  limitToLast
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/* ================= FIREBASE ================= */

const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

/* ================= BONUS SETTINGS ================= */

const NORMAL_SIGNUP_BONUS = 3000;
const EXTRA_REFERRAL_BONUS = 2000;
const REFERRER_BONUS = 1500;

/* ================= UTILITIES ================= */

function generateCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function getReferralFromURL() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ref");
}

function getDeviceId() {
  let id = localStorage.getItem("deviceId");
  if (!id) {
    id = generateCode() + Date.now();
    localStorage.setItem("deviceId", id);
  }
  return id;
}

/* ================= AUTH ================= */

onAuthStateChanged(auth, async (user) => {

  if (!user) {
    window.location.href = "index.html";
    return;
  }

  const uid = user.uid;
  const userRef = ref(db, "users/" + uid);

  try {

    const snap = await get(userRef);

    /* ========= NEW USER ========= */
    if (!snap.exists()) {

      const myCode = generateCode();
      const referralFromURL = getReferralFromURL();
      const deviceId = getDeviceId();

      const newUser = {
        email: user.email,
        username: user.email.split("@")[0],
        wallet: NORMAL_SIGNUP_BONUS,   // 3000
        referrals: 0,
        referralEarnings: 0,
        referralCode: myCode,
        referredBy: null,
        referralBonusReceived: false,
        deviceId: deviceId,
        createdAt: Date.now()
      };

      await set(userRef, newUser);
      await set(ref(db, "referralCodes/" + myCode), uid);

      if (referralFromURL) {
        try {
          await applyReferral(uid, referralFromURL, deviceId);
        } catch (err) {
          console.log("Referral error:", err);
        }
      }
    }

    /* ========= OLD USER FIX ========= */
    else {
      const data = snap.val();

      if (!data.referralCode) {
        const newCode = generateCode();
        await update(userRef, { referralCode: newCode });
        await set(ref(db, "referralCodes/" + newCode), uid);
      }
    }

  } catch (error) {
    console.log("User load error:", error);
  }

  loadUser(uid);
  loadLeaderboard();
});

/* ================= APPLY REFERRAL ================= */

async function applyReferral(newUid, code, deviceId) {

  const codeSnap = await get(ref(db, "referralCodes/" + code));
  if (!codeSnap.exists()) return;

  const ownerUid = codeSnap.val();
  if (ownerUid === newUid) return;

  const ownerRef = ref(db, "users/" + ownerUid);
  const ownerSnap = await get(ownerRef);
  if (!ownerSnap.exists()) return;

  if (ownerSnap.val().deviceId === deviceId) return;

  const newUserRef = ref(db, "users/" + newUid);
  const newUserSnap = await get(newUserRef);

  if (newUserSnap.val().referralBonusReceived) return;

  /* 🔥 GIVE NEW USER +2000 */
  await runTransaction(newUserRef, (data) => {
    if (data) {
      data.wallet += EXTRA_REFERRAL_BONUS;
      data.referredBy = code;
      data.referralBonusReceived = true;
    }
    return data;
  });

  /* 🔥 GIVE REFERRER +1500 */
  await runTransaction(ownerRef, (data) => {
    if (data) {
      data.wallet += REFERRER_BONUS;
      data.referrals = (data.referrals || 0) + 1;
      data.referralEarnings =
        (data.referralEarnings || 0) + REFERRER_BONUS;
    }
    return data;
  });
}

/* ================= LOAD USER ================= */

function loadUser(uid) {

  const userRef = ref(db, "users/" + uid);

  onValue(userRef, (snap) => {

    const data = snap.val();
    if (!data) return;

    const usernameEl = document.getElementById("username");
    const walletEl = document.getElementById("wallet");
    const codeEl = document.getElementById("refCode");
    const earningsEl = document.getElementById("refEarnings");

    if (usernameEl) usernameEl.innerText = data.username;

    if (walletEl)
      walletEl.innerText =
        "UGX " + (data.wallet || 0).toLocaleString();

    if (codeEl)
      codeEl.innerText =
        data.referralCode || "----";

    if (earningsEl)
      earningsEl.innerText =
        "UGX " + (data.referralEarnings || 0).toLocaleString();
  });
}

/* ================= LEADERBOARD ================= */

function loadLeaderboard() {

  const container = document.getElementById("leaderboardList");
  if (!container) return;

  const leaderboardRef = query(
    ref(db, "users"),
    orderByChild("referrals"),
    limitToLast(10)
  );

  onValue(leaderboardRef, (snap) => {

    container.innerHTML = "";

    const users = [];

    snap.forEach(child => {
      users.push(child.val());
    });

    users.reverse().forEach(user => {

      const div = document.createElement("div");
      div.className = "leader-item";

      div.innerHTML = `
        <span>${user.username}</span>
        <span>${user.referrals || 0}</span>
      `;

      container.appendChild(div);
    });
  });
}

/* ================= SHARE + COPY ================= */

document.addEventListener("click", (e) => {

  if (e.target.id === "copyBtn") {
    const code = document.getElementById("refCode")?.innerText;
    if (!code) return;

    navigator.clipboard.writeText(code);
    alert("Referral code copied!");
  }

  if (e.target.id === "shareBtn") {
    const code = document.getElementById("refCode")?.innerText;
    if (!code) return;

    const link = window.location.origin + "/signup.html?ref=" + code;
    const message =
      "Join Kola and earn money watching videos! Use my link: " + link;

    window.open("https://wa.me/?text=" + encodeURIComponent(message));
  }
});

/* ================= LOGOUT ================= */

window.logout = function () {
  signOut(auth).then(() => {
    window.location.href = "index.html";
  });
};