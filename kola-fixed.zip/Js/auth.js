const auth = firebase.auth();

function togglePassword() {
  const pass = document.getElementById("password");
  pass.type = pass.type === "password" ? "text" : "password";
}

function login() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const msg = document.getElementById("msg");

  msg.innerText = "Logging in...";

  auth.signInWithEmailAndPassword(email, password)
    .then(userCredential => {
      const user = userCredential.user;

      if (!user.emailVerified) {
        msg.innerText = "Please verify your email first.";
        auth.signOut();
        return;
      }

      window.location.href = "dashboard.html";
    })
    .catch(error => {
      msg.innerText = error.message;
    });
}
function signup() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const msg = document.getElementById("msg");
  const btn = document.getElementById("signupBtn");

  if (!email || !password) {
    msg.innerText = "Please fill all fields.";
    return;
  }

  if (password.length < 6) {
    msg.innerText = "Password must be at least 6 characters.";
    return;
  }

  btn.disabled = true;
  btn.innerText = "Creating...";

  auth.createUserWithEmailAndPassword(email, password)
    .then(userCredential => {
      const user = userCredential.user;

      return user.sendEmailVerification();
    })
    .then(() => {
      msg.style.color = "#00ff88";
      msg.innerText = "Verification email sent. Check your inbox.";

      auth.signOut();
      btn.innerText = "Account Created";
    })
    .catch(error => {
      msg.style.color = "#ff8080";
      msg.innerText = error.message;
      btn.disabled = false;
      btn.innerText = "Create Account";
    });
}