import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  get
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/* ================= FIREBASE CONFIG ================= */

const firebaseConfig = {
  apiKey: "AIzaSyAWLwLHt1js0r-kqPh1styJYctLITYniWs",
  authDomain: "kola-c8186.firebaseapp.com",
  databaseURL: "https://kola-c8186-default-rtdb.firebaseio.com",
  projectId: "kola-c8186",
  storageBucket: "kola-c8186.appspot.com",
  messagingSenderId: "937444551619",
  appId: "1:937444551619:web:36333805066ce3a219ab76"
};

/* ================= INIT FIREBASE ================= */

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

/* ================= DOM ================= */

const loginBtn = document.getElementById("loginBtn");
const errorMsg = document.getElementById("errorMsg");

/* ================= LOGIN ================= */

loginBtn.addEventListener("click", async () => {

  errorMsg.innerText = "";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    errorMsg.innerText = "Please enter email and password.";
    return;
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // 🔥 CHECK ADMIN USING UID (MATCHES DASHBOARD)
    const adminSnap = await get(ref(db, "admins/" + user.uid));

    if (!adminSnap.exists()) {
      await signOut(auth);
      errorMsg.innerText = "Access denied. You are not an admin.";
      return;
    }

    // ✅ Admin confirmed
    window.location.href = "admin-dashboard.html";

  } catch (error) {
    errorMsg.innerText = "Login failed: " + error.message;
  }
});

/* ================= AUTO REDIRECT IF LOGGED ================= */

onAuthStateChanged(auth, async (user) => {

  if (!user) return;

  const adminSnap = await get(ref(db, "admins/" + user.uid));

  if (adminSnap.exists()) {
    window.location.href = "admin-dashboard.html";
  } else {
    await signOut(auth);
  }

});